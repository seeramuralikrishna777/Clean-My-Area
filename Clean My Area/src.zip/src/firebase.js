// frontend/src/firebase.js

export const auth = {
  signOut: () => {
    // Simulate sign-out behavior (does nothing real)
    console.log("Logged out (fake auth)");
  },
};
