import React from 'react';

const ProfilePage = () => {
  return (
    <div className="p-6">
      <h1 className="text-2xl font-bold">Profile Page</h1>
      <p>This is a placeholder profile page.</p>
    </div>
  );
};

export default ProfilePage;
